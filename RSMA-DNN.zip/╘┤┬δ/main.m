clear;
clc;

%% =========================
%  1. 加载数据
%  说明：
%  这里默认 'Inception V4.mat' 中包含变量 MHPCP
%  若不包含，请改成你自己的数据加载方式
% ==========================
load('Inception V4.mat');

%% =========================
%  2. 系统参数设置
% ==========================
snr_dB      = 40;                  % 信噪比(dB)
Pt          = 10^(snr_dB / 10);    % 总发射功率（线性值）
B           = 1e7;                 % 带宽：10 MHz
tolerance   = 1e-3;                % SCA 收敛阈值
Nt          = 2;                   % 发射天线数
alpha_m     = 2;                   % 路损系数
yita        = 0.5;                 % 初始私有流功率比例
rate_min    = 0.1;                 % 最小速率约束
E_flops     = 1e-7;                % 单位计算能耗系数
max_A_iter  = 10;                  % 外层交替优化次数
omiga       = 0.7;                 % 时延/能耗权重系数

% 热噪声功率（由 -174 dBm/Hz 换算）
n0 = 10^(-174/10) / 1000 * B * (1e6)^2;

% 初始公共流功率
P_c = Pt * (1 - yita);

%% =========================
%  3. Inception-v4 任务图参数
%  task_cost    : 每个任务节点的计算量
%  edge_weights : DAG 边上传输的数据量
% ==========================
task_cost = [ ...
    0, 121363200, 30184000, 30184000, 22657600, ...
    30184000, 33986400, 67894400, 0 ...
] * 6;

edge_weights = [ ...
    627200, 1881600, 1881600, 1881600, 1881600, ...
    156800, 156800, 156800, 156800, 235200, 313600 ...
] * 6;

numTasks = numel(task_cost);
numEdges = numel(edge_weights);

%% =========================
%  4. 构建固定任务图（HEFT 使用）
% ==========================
s = [1 1 1 1 2 3 4 5 6 7 8];
t = [2 3 4 6 9 9 5 9 7 8 9];

taskGraph = digraph;
taskGraph = addedge(taskGraph, s, t);

taskNames = arrayfun(@num2str, 1:numTasks, 'UniformOutput', false);
taskGraph.Nodes.Name = taskNames';

% 将边数据量转换为邻接矩阵，便于后续更新 Data
data_tran_matrix = full(sparse(s, t, edge_weights, numTasks, numTasks));

%% =========================
%  5. 结果变量初始化
% ==========================
numVehicles    = size(MHPCP, 1);
K_HEFT         = zeros(numVehicles, 1);       % 每辆车最终调度周期
plan           = zeros(numTasks, numVehicles);% 每个任务节点的卸载位置
offloading_plan = cell(numVehicles, 1);       % 完整调度方案
RSMA_Rate      = cell(numVehicles, 1);        % RSMA 最终速率

%% =========================
%  6. 对每个车辆场景进行联合优化
% ==========================
for j = 1:numVehicles

    % ---------- 当前车辆场景基础信息 ----------
    K = length(MHPCP{j, 2});          % AU数量
    H = MHPCP{j, 4};                  % 信道矩阵
    LOS_au = MHPCP{j, 8};             % AU链路LOS/路径增益
    location_RSU = MHPCP{j, 1};       % RSU位置
    Q = [MHPCP{j, 5}, MHPCP{j, 6}];   % 各计算节点计算能力

    % ---------- 初始化功率分配 ----------
    P_p = yita * Pt / (K + 1);        % 每条私有流初始功率

    % 公共流预编码初始化：取 H 的主奇异向量方向
    [U, ~, ~] = svd(H);
    pcprecoder = U(:, 1) * sqrt(P_c);

    % 私有流预编码初始化：对每列信道归一化
    Ppiprecoder = H ./ vecnorm(H, 2, 1) * sqrt(P_p);
    Pp = Ppiprecoder;

    % ---------- 计算 RSU 路径损耗 ----------
    dis_rsu = sqrt((location_RSU - 50)^2 + 10^2);
    LOS_rsu = dis_rsu^(-alpha_m);

    % 所有链路路径增益（AU + RSU）
    LOS = [LOS_au(:); LOS_rsu];

    % ---------- 初始化干扰项 ----------
    beta_gamma  = zeros(K + 1, 1);    % 私有流干扰 + 噪声前项
    betac_gamma = zeros(K + 1, 1);    % 公共流干扰 + 噪声前项

    for l = 1:(K + 1)
        for i = 1:(K + 1)
            if i ~= l
                beta_gamma(l) = beta_gamma(l) + LOS(l) * abs(H(:, l)' * Pp(:, i))^2;
            end
            betac_gamma(l) = betac_gamma(l) + LOS(l) * abs(H(:, l)' * Pp(:, i))^2;
        end
    end

    beta  = beta_gamma  + n0;
    betac = betac_gamma + n0;

    % ---------- 初始化能耗与数据量 ----------
    eta  = ones(K + 1, 1);
    Data = 600 * ones(K + 1, 1) + 0.1;
    Data(K + 1) = Data(K + 1) + 100;  % RSU 额外初始数据量

    % 外层交替优化：RSMA 速率分配 + HEFT 调度
    for outerIter = 1:max_A_iter

        %% =========================================
        %  6.1 内层：基于 SCA 的 RSMA 优化
        % ==========================================
        tPrevious = -inf;
        maxIter = 1000;

        for iter = 1:maxIter

            cvx_begin quiet
                variable time
                variable alpha1(K + 1)
                variable alphac(K + 1)
                variable gamma1(K + 1)
                variable gammac1(K + 1)
                variable rho1(K + 1)
                variable rhoc(K + 1)
                variable p(Nt, K + 1) complex
                variable pc(Nt) complex
                variable c(K + 1)
                variable R(K + 1)
                variable E1(K + 1)
                variable med_P(K + 1)

                expression gamma2(K + 1)
                expression P1
                expression P2
                expression t1

                P1 = 0;
                t1 = 0;

                minimize(time)

                subject to
                    for i = 1:(K + 1)

                        % ---------- 速率与公共流分配约束 ----------
                        c(i) >= 0;
                        sum(c) <= alphac(i);
                        R(i) <= alpha1(i) + c(i);
                        R(i) >= rate_min;

                        log(1 + rho1(i)) / log(2) >= alpha1(i);
                        log(1 + rhoc(i)) / log(2) >= alphac(i);

                        % ---------- 私有流 SCA 线性化约束 ----------
                        LOS(i) * ( ...
                            2 * real(Pp(:, i)' * H(:, i) * H(:, i)' * p(:, i)) / beta(i) ...
                            - square_abs(H(:, i)' * Pp(:, i) / beta(i)) * gamma1(i) ...
                        ) >= rho1(i);

                        % ---------- 公共流 SCA 线性化约束 ----------
                        LOS(i) * ( ...
                            2 * real(pcprecoder' * H(:, i) * H(:, i)' * pc) / betac(i) ...
                            - square_abs(H(:, i)' * pcprecoder / betac(i)) * gammac1(i) ...
                        ) >= rhoc(i);

                        % ---------- 干扰项更新 ----------
                        gamma2 = square_abs(H(:, i)' * p);
                        gamma1(i)  >= LOS(i) * sum(gamma2([1:i-1, i+1:end])) + n0;
                        gammac1(i) >= LOS(i) * sum(gamma2) + n0;

                        % ---------- 总功率与时延累计 ----------
                        P1 = P1 + p(:, i)' * p(:, i);
                        t1 = t1 + Data(i) * inv_pos(R(i));
                    end

                    % ---------- 能耗建模 ----------
                    for i = 1:(K + 1)
                        med_P(i) >= p(:, i)' * p(:, i) + pc' * pc;
                        E1(i) >= med_P(i) * Data(i) - eta(i) * R(i);
                    end

                    % ---------- 总功率约束 ----------
                    P2 = P1 + pc' * pc;
                    P2 <= Pt;

                    % ---------- 目标函数：时延+能耗 ----------
                    time >= omiga * t1 + (1 - omiga) * sum(E1);
            cvx_end

            % 用当前解更新 SCA 线性化点
            beta  = gamma1;
            betac = gammac1;

            fprintf('RSMA | vehicle = %d | outer = %d | iter = %d | obj = %.6f | diff = %.6f\n', ...
                j, outerIter, iter, time, abs(time - tPrevious));

            if abs(time - tPrevious) <= tolerance
                break;
            end

            % 更新分式规划参数 eta
            for i = 1:(K + 1)
                eta(i) = med_P(i) * Data(i) / R(i);
            end

            tPrevious = time;
            Pp = p;
            pcprecoder = pc;
        end

        % 保存当前 RSMA 速率
        RSMA_Rate{j} = R;

        %% =========================================
        %  6.2 基于当前速率计算 HEFT 所需代价
        % ==========================================
        t_com  = zeros(numTasks, K + 1);  % 计算时延
        t_tran = zeros(numEdges, K + 1);  % 传输时延
        E_com  = zeros(numTasks, K + 1);  % 计算能耗
        E_tran = zeros(numEdges, K + 1);  % 传输能耗

        for i = 1:(K + 1)
            t_com(:, i)  = task_cost(:) ./ Q(i);
            t_tran(:, i) = edge_weights(:) ./ (R(i) * B);

            E_com(:, i)  = task_cost(:) * E_flops;
            E_tran(:, i) = (p(:, i)' * p(:, i) + pc' * pc) * t_tran(:, i);
        end

        % HEFT 的计算代价表与通信代价表
        cost_table = omiga * t_com * 1000 + (1 - omiga) * E_com;
        weights    = omiga * t_tran + (1 - omiga) * E_tran;

        %% =========================================
        %  6.3 执行 HEFT 调度
        % ==========================================
        ScheduleDB = heft(taskGraph, cost_table, weights);

        % 第3列通常表示任务被分配到哪个处理节点
        curr_plan = table2array(ScheduleDB.NodeSchedule(:, 3));

        %% =========================================
        %  6.4 根据调度结果更新 Data，用于下一轮外层优化
        % ==========================================
        for nodeIdx = 2:numel(curr_plan)
            node_predecessors = predecessors(taskGraph, nodeIdx);

            for n = 1:length(node_predecessors)
                predNode = node_predecessors(n);

                % 若前驱任务与当前任务不在同一节点执行，或前驱为源节点，则产生额外传输
                if curr_plan(predNode) ~= curr_plan(nodeIdx) || predNode == 1
                    targetProcessor = curr_plan(nodeIdx);
                    Data(targetProcessor) = Data(targetProcessor) + data_tran_matrix(predNode, nodeIdx);
                end
            end
        end

        % 归一化数据量
        Data = Data / B;
    end

    %% =========================
    %  7. 保存当前车辆场景结果
    % ==========================
    K_HEFT(j) = ScheduleDB.Cycles;
    plan(:, j) = curr_plan;
    offloading_plan{j} = ScheduleDB.NodeSchedule;

    fprintf('vehicle | %d | delay = %.6f\n', j, K_HEFT(j));
end