%泊松簇过程仿真
%父过程
clc;clear;close all;
lambda = 20;                       % 密度
M = 0;
U = unifrnd(0,1);

while U >= exp(-lambda)           %判定条件
    U = U*unifrnd(0,1);
    M=M+1;
end

if M < 1
    M = 1;
end

L = 100;
a = 0;b = L;      %取[0,100]*[0,100]*[0,100]的布点区域；
c = 0;d = 0;
A = zeros(1,M);
B = zeros(1,M);
for i = 1:M
    U1 = unifrnd(0,1);
    A(i) = (b-a)*U1;
    U2 = unifrnd(0,1);
    B(i) = (d-c)*U2;
    plot(A(i),B(i),'r^');
    hold on;
end
grid on;
%% step 2  标记点
mark=unifrnd(0,1,1,length(A)); % 对应于Hppp矩阵,0到1之间，1行M列
[marknew,index]=sort(mark);  %Matlab中给一维向量排序是使用sort函数: sort (X)，其中x为待排序的向量。若欲保留排列前的索引，则可用[sX,index] = sort(X)，
%排序后，sX是排序好的向量，index是 向量sX中对X的索引。事实上这里X=sX(index), [X恒等于sX(index)]，

for i=1:length(mark)
    newA(:,i)=A(:,index(i)); %index(i)表示index矩阵中第i个元素
end

%计算两点之间的距离
distance=zeros(length(mark),length(mark));
for i=1:length(mark)
    for j=i+1:length(mark)
        distance(i,j)=sqrt(sum((newA(:,i)-newA(:,j)).^2)); %计算列与列间欧式几何距离
    end
end
distance=distance+distance'; %b应该是对角矩阵，上边循环只计算一半，这里补另一半

%% step3距离判别

Y0=5; % 硬核距离
j=1; 
indexpoint=ones(1,length(mark));%生成1行length(mark)列的全1矩阵
dis=(distance>=Y0);

for i=1:length(mark)
    for j=i+1:length(mark)
        if indexpoint(i)==1
            if dis(i,j)==0
                indexpoint(j)=0;
            end
        end
    end
end
temp=find(indexpoint==1);

% Mhcpp画图
for t=1:length(temp)
    MHPPPA(:,t)=newA(:,temp(t));
    MHPPPB(:,t)=0;
end
MHPPPA=sort(MHPPPA);
for j=1:length(MHPPPA)
MHPCP(j,1)={MHPPPA(:,j)};
end

%%
%子过程
HPCPx=[];
HPCPy=[];
M=length(temp);
for j=1:M
    n = 20;
    r = 5;
    u1 = zeros(1,n);
    u2 = zeros(1,n);
    R = zeros(1,n);
    x = zeros(1,n);
    y = zeros(1,n);    theta = zeros(1,n);

    for i = 1:n
        u1(i) = unifrnd(0,1);
    end

    R = r * sqrt(u1);
    R = sort(R);

    for i = 1:n
        u2(i) = unifrnd(0,1);
    end

    theta = 2*pi*u2;

    for i = 1:n
        x(i) =  MHPPPA(j) + R(i) * cos(theta(i));
        y(i) =  MHPPPB(j) + R(i) * sin(theta(i));
        com_x(i)=abs(x(i)- MHPPPA(j));
        com_y(i)=abs(y(i)- MHPPPB(j));
    end
    Mx(j,1)={x};
    My(j,1)={y};
    plot(x,y,'.b');
    xdis=(com_x>=4);
    ydis=(com_y>=2);
    temp=union(find(xdis==1),find(ydis==1));
     Mx(j,1)={x(temp)};
     My(j,1)={y(temp)};
    HPCPx=[HPCPx x(temp)];
    HPCPy=[HPCPy y(temp)];
end
axis([-10,110,-10,110]);
figure(2)
plot(MHPPPA,MHPPPB,'r^',HPCPx,HPCPy,'.b');
axis([-4,110,-4,4]);
%     HPCPx=[HPCPx A];
%     HPCPy=[HPCPy B];
%% step 2  标记点
mark=unifrnd(0,1,1,length(HPCPx)); % 对应于Hppp矩阵,0到1之间，1行M列
[marknew,index]=sort(mark);  %Matlab中给一维向量排序是使用sort函数: sort (X)，其中x为待排序的向量。若欲保留排列前的索引，则可用[sX,index] = sort(X)，
%排序后，sX是排序好的向量，index是 向量sX中对X的索引。事实上这里X=sX(index), [X恒等于sX(index)]，

for i=1:length(mark)
    newHPCPx(:,i)=HPCPx(:,index(i)); %index(i)表示index矩阵中第i个元素
    newHPCPy(:,i)=HPCPy(:,index(i)); %index(i)表示index矩阵中第i个元素
end

%计算两点之间的距离
distance=zeros(length(mark),length(mark));
for i=1:length(mark)
    for j=i+1:length(mark)
        distance(i,j)=sqrt(sum((newHPCPx(:,i)-newHPCPx(:,j)).^2)+sum((newHPCPy(:,i)-newHPCPy(:,j)).^2)); %计算列与列间欧式几何距离
    end
end
distance=distance+distance'; %b应该是对角矩阵，上边循环只计算一半，这里补另一半

%% step3距离判别

Y1=5; % 硬核距离
j=1; interindex=0;
indexpoint=ones(1,length(mark));%生成1行length(mark)列的全1矩阵
dis=(distance>=Y1);

for i=1:length(mark)
    for j=i+1:length(mark)
        if indexpoint(i)==1
            if dis(i,j)==0
                indexpoint(j)=0;
            end
        end
    end
end
temp=find(indexpoint==1);

% Mhcpp画图
for t=1:length(temp)
    MHPCPx(:,t)=newHPCPx(:,temp(t));
    MHPCPy(:,t)=newHPCPy(:,temp(t));
end
for j=1:length(MHPPPA)
[~,index,~]=intersect(MHPCPx,Mx{j,1});
MHPCP(j,2)={MHPCPx(:,index)};
MHPCP(j,3)={MHPCPy(:,index)};
end
% mhp=sort(Mhcpp);
figure(3)
plot(MHPPPA,MHPPPB,'r^',MHPCPx,MHPCPy,'.b')

grid on;

filename = 'MHPCP.mat';
save(filename, ...
    'MHPCP');