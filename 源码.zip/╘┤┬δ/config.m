load('MHPCP.mat')
%% 车辆信道

% K = 2;%辅助节点个数
Nt = 2;%任务车辆天线数
% v=30;%km/h
channel_num = 1;
sigma2=10 ^ (-104/10); %高斯分布方差  % Variance of the channel estimation errors
alpha_m= 2;%路损系数
q_m=2;%nakagami形状参数
rate_min=1e6;%最小速度1000b/s
B=10^6;%带宽2MHZ
Pt = 10 ^ (30/10)/1000;%总发射功率30dBm 1w
P0 = 10 ^ (-94/10); %-94dbm
tolerance = 1e-3;
n0 = 10 ^ (-104/10);%噪声功率-174dBm 

%--------------------------信道建模-----------------------------------------
%H=2*2 行数为发射天线数，列为辅助计算节点数
for j=1:size(MHPCP,1)
    K=length(MHPCP{j,2})+1;
H_esi=random(makedist('Nakagami', 'mu', q_m, 'omega', 1), Nt,K, channel_num ...
    ) .* exp(1i*(-pi + (pi+pi)*rand(Nt,K, channel_num)));% Matrix of channel estimation
H_err=sqrt(sigma2/2)*(randn(Nt,K,channel_num)+1i*randn(Nt,K,channel_num));    % Matrix of channel errors
H=H_esi+H_err;  %信道矩阵      %1代表辅助计算mecBS，2代表辅助计算车辆ub
MHPCP{j,4}=H;
end
%% 基站、车辆计算能力及行进速度
fr=2*1e12;%车辆计算能力
fr_RSU=100*1e12;
r1=rand(size(MHPCP, 1),1);
r1 = r1 / sum(r1);
fr_rsu_all = fr_RSU * r1;

t_min=1;

for j=1:size(MHPCP,1)
    K=length(MHPCP{j,2});
Fr=fr+fr*rand(1,K);
MHPCP{j,5}=Fr;
MHPCP{j,6} = fr_rsu_all(j);

v=30+30*rand(1,1);
v1=v./3.6;
t_stay=abs((100-MHPCP{j,1})./v1);
MHPCP{j,7}=min(t_stay,t_min);
MHPCP{j,9}=v1;
end
%% 
for j=1:size(MHPCP,1)
    K=length(MHPCP{j,2});
    dis_au=[];
    LOS_au=[];
    for i=1:K
        dis_au(i)=sqrt(abs(MHPCP{j,2}(i)-MHPCP{j,1})^2+abs(MHPCP{j,3}(i))^2);
        LOS_au(i)=dis_au(i)^(-alpha_m)
    end
    MHPCP{j,8}=LOS_au;
end

%% DNN模型
Name = {'1' '2' '3' '4' '5' '6' '7' '8' '9'};
cost_table=30*rand(9,3);
Graph = digraph;
s = [1 1 1 1 2 ...
3 4 5 6 7 8 ];
t = [2 3 4 6 9 ...
9 5 9 7 8 9 ];
weights=[10 10 1 10 1 10 1 2 2 2 2];
Graph = addedge(Graph,s,t,weights);
plot(Graph)
Inceptionv4_cost=[0   121363200 30184000   30184000    22657600 ...
    30184000  33986400 67894400 0];
Inceptionv4_weights = [627200 1881600 1881600 1881600 1881600 ...
156800 156800 156800 156800 235200 313600];
filename='Inception V4';
save(filename, ...
    'cost_table',...
    'Graph',...
    'Inceptionv4_cost',...
    'Inceptionv4_weights',...
    'MHPCP');
% name_MHPCP=[{'TU_side'} {'AU_x'} {'AU_y'} {'TU_H'} {'AU_Q'} {'RSU_Q'} {'TU_V'} {'AU_LOS'}]
%  MHPCP={name_MHPCP;MHPCP}