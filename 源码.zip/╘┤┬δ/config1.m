clear all;clc;
load('Inception V4.mat');
a = sum(cell2mat(MHPCP(:,6)), 1);