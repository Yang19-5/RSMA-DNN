% function [ranks] = rankNodes(Graph,cost)
% % Find the rank of each node
% 
% ranks = zeros(1,height(Graph.Nodes));
% start_nodes = find(indegree(Graph) == 0);
% 
% for i = 1:length(start_nodes)
%     [ranks] = calcRank(Graph, ranks, cost, start_nodes(i));
% end
% 
% end
% 
% function [ranks] = calcRank(Graph,ranks,cost,curr_node)
% % Calculate recursively the rank of each node
% 
% if ranks(curr_node)
%     return
% end
% 
% succ = successors(Graph,curr_node);
% if isempty(succ)
%     ranks(curr_node) = cost(curr_node);
%     return
% end
% 
% for i=1:length(succ)
%     ranks = calcRank(Graph,ranks,cost,succ(i));
% end
% 
% ranks(curr_node) = cost(curr_node) + max( distances(Graph,curr_node,succ) + ranks(succ) );
% 
% end



function [ranks] = rankNodes(Graph, cost, weights)
% 计算每个节点的 upward rank（用于HEFT等算法）
% 输入:
%   Graph   - 有向任务图 (digraph)
%   cost    - 每个节点的平均计算时间或估算成本
%   weights - N x P 的通信延迟矩阵，weights(i, p) 是第i个节点在第p个处理器上的通信参数
Graph1=Graph;
Graph1.Edges.Weights=weights;
ranks = zeros(1, height(Graph1.Nodes));
start_nodes = find(indegree(Graph1) == 0);

for i = 1:length(start_nodes)
    [ranks] = calcRank(Graph, ranks, cost, start_nodes(i));
end
end

function [ranks] = calcRank(Graph,ranks,cost,curr_node)
% Calculate recursively the rank of each node

if ranks(curr_node)
    return
end

succ = successors(Graph,curr_node);
if isempty(succ)
    ranks(curr_node) = cost(curr_node);
    return
end

for i=1:length(succ)
    ranks = calcRank(Graph,ranks,cost,succ(i));
end

ranks(curr_node) = cost(curr_node) + max( distances(Graph,curr_node,succ) + ranks(succ) );

end
