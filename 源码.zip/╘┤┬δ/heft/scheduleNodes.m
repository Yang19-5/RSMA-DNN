function [nodes_schedule] = scheduleNodes(Graph, order, cost_table, weights)
% 任务调度函数，考虑通信延迟（依赖于处理器分配）
% 输入:
%   Graph       - 有向图结构（digraph）
%   order       - 节点执行顺序（拓扑排序）
%   cost_table  - 每个节点在各处理器上的执行时间 (N x P)
%   weights     - 通信时延矩阵 (N x P)，表示节点在不同处理器的通信权重
% 输出:
%   nodes_schedule - 包含每个节点调度信息的表格

    nodes_names = Graph.Nodes.Name;
    processors = size(cost_table,2);
    num_nodes = length(order);

    EFT = zeros(num_nodes,1);         % Earliest Finish Time
    EST = zeros(num_nodes,1);         % Earliest Start Time
    assigned_proc = zeros(num_nodes,1); % 分配的处理器编号（从1开始）
    procs_eft = zeros(1,processors);  % 各处理器当前可用时间

    for i = 1:num_nodes
        curr_node = order(i);
        pred_nodes = predecessors(Graph, curr_node);
        temp_eft = zeros(processors,1);

        if ~isempty(pred_nodes)
            for k = 1:processors
                comm_delay = zeros(length(pred_nodes), 1);
                for p = 1:length(pred_nodes)
                    pred = pred_nodes(p);
                    if assigned_proc(pred) ~= k
                        distances(Graph,pred_nodes,curr_node)
                        % 通信时延 = weights(curr_node, pred的处理器) + weights(curr_node, 当前处理器)
                        edge_idx = getEdgeWeight(Graph, pred, curr_node);
                        comm_delay(p) = weights(edge_idx, assigned_proc(pred)) + weights(edge_idx, k);
                    else
                        comm_delay(p) = 0;
                    end
                end
                % 每个处理器k，当前节点的最早开始时间 = max(前驱完成时间 + 通信时延)
                pred_efts = EFT(pred_nodes) + comm_delay;
                start_time = max(procs_eft(k), max(pred_efts));
                temp_eft(k) = start_time + cost_table(curr_node, k);
            end
        else
            % 没有前驱，直接排在该处理器空闲后的时间上
            temp_eft = procs_eft + cost_table(curr_node, :);
        end

        % 选择完成时间最早的处理器
        [EFT(curr_node), assigned_proc(curr_node)] = min(temp_eft);
        EST(curr_node) = EFT(curr_node) - cost_table(curr_node, assigned_proc(curr_node)) + 1;

        % 更新处理器的最早可用时间
        procs_eft(assigned_proc(curr_node)) = EFT(curr_node);
    end

    % 返回调度结果表格
    nodes_schedule = table((1:num_nodes)', nodes_names(order), assigned_proc(order), EST(order), EFT(order), ...
        'VariableNames', {'NodeID', 'NodeName', 'Processor', 'EST', 'EFT'});
end


function idx = getEdgeWeight(Graph, pred, curr)
%GETEDGEWEIGHT 返回 Graph 中 pred -> curr 的边索引
%   pred, curr 是节点的 index (数字)
%   如果存在边，则返回其索引；如果不存在，返回 0

    pred_name = Graph.Nodes.Name{pred};
    curr_name = Graph.Nodes.Name{curr};

    % 精确查找 pred->curr 的边
    idx = find(strcmp(Graph.Edges.EndNodes(:,1), pred_name) & ...
               strcmp(Graph.Edges.EndNodes(:,2), curr_name));

    if isempty(idx)
        idx = 0;  % 没有找到边
    end
end

