clear all;clc;
load('Inception V4.mat');
%config;
snrdB=40;
Pt = 10 ^ (snrdB/10);
B=10^7;%带宽2MHZ
tolerance = 1e-3;
P0 = 10 ^ (-94/10); %-94dbm
n0 = 10 ^ (-174/10)/1000*B*(1e6)^2; %-94dbm
Nt=2;
%噪声功率-174dBm
alpha_m= 2;%路损系数
yita=0.5;%公私有初始功率分配系数
a=1e15;
P_c = Pt * (1-yita);%初始公私有功率值
rate_min=0.1;
E_flops=1e-7;
max_A_iter=10;
omiga=0.7;
        Inceptionv4_cost=[0   121363200 30184000   30184000    22657600 ...
            30184000  33986400 67894400 0]*6;
        Inceptionv4_weights = [627200 1881600 1881600 1881600 1881600 ...
            156800 156800 156800 156800 235200 313600]*6;
for j=1:size(MHPCP,1)
    cost_table=[];
    weights=[];
    Data=[];
    t_com=[];
    t_tran=[];
    E_com= [];
    E_tran=[];
    K=length(MHPCP{j,2});
    P_p = yita*Pt / (K+1);
    H=MHPCP{j,4};
    [U, ~, ~] = svd(H);
    pcprecoder = U(:,1) * sqrt(P_c);%公有预编码方向
    Ppiprecoder = H ./ vecnorm(H) * sqrt(P_p);%私有预编码方向矩阵
    Pp = Ppiprecoder;
    Pp_au=Ppiprecoder(:,1:K);
    Pp_RSU=Ppiprecoder(:,K+1);
    LOS_au=MHPCP{j,8};
    location_RSU=MHPCP{j,1};
    if location_RSU<50
        dis_RSU(j)=sqrt(abs(50-location_RSU)^2+abs(10)^2);
    else
        dis_RSU(j)=sqrt(abs(location_RSU-50)^2+abs(10)^2);
    end

    LOS_RSU=dis_RSU(j)^(-alpha_m);
    LOS=[LOS_au LOS_RSU];
    beta_gamma=zeros(1,K+1);
    betac_gamma=zeros(1,K+1);
    for l=1:K+1
        for i=1:K+1
            if i ~=l
                beta_gamma(:,l)=beta_gamma(:,l)+LOS(l)*square_abs(H(:,l)' * Pp(:,i))
            end

            betac_gamma(:,l)=betac_gamma(:,l)+LOS(l)*square_abs(H(:,l)' * Pp(:,i))
        end

    end


    beta=beta_gamma+n0;
    betac=betac_gamma+n0;
    eta=ones(1,K+1);
    D=600*ones(1,K+1);
    Data=D+0.1;
    Data(K+1)=Data(K+1)+100;
    for A_iter=1:max_A_iter

        % [pE2(t), pb2(t), p1(t), c(t), maxsumrate(t),Rate_aE(t),Rate_ab(t)] = ...
        % f5_rsma_sca(H, tolerance,ploss_aE(t),ploss_ab(t),...
        % pb2precoder,pE2precoder,p1precoder,gamma_m1(t,:),gamma_m2(t,:));
        tPrevious = -inf;%无穷小

        maxIter = 1000;
        for iter = 1:maxIter

            cvx_begin quiet
            variable time
            variable alpha1(K+1)
            variable alphac(K+1)
            variable gamma1(K+1)
            variable gammac1(K+1)
            variable rho1(K+1)
            variable rhoc(K+1)
            variable p(Nt,K+1) complex
            variable pc(Nt) complex
            variable c(K+1)
            variable R(K+1)
            expression gamma2
            %         expression gammac2(K+1)
            expression P1
            expression P2
            %         expression P2c
            expression t1
            variable E1(K+1)
            variable med_P(K+1)
            minimize(time)
            subject to
            for i = 1:K+1
                c(i)>=0
                sum(c) <=alphac(i)
                R(i) <= alpha1(i) + c(i)
                R(i)>=rate_min
                log(1 + rho1(i)) / log(2) >= alpha1(i)
                log(1 + rhoc(i)) / log(2) >= alphac(i)


                LOS(i)*(2 * real(Pp(:,i)' * H(:, i) * H(:,i)' * p(:,i)) / ...
                    beta(i) - ...
                    square_abs(H(:,i)' * Pp(:,i) / ...
                    beta(i)) * gamma1(i)) >= rho1(i)

                LOS(i)* (2 * real(pcprecoder' * H(:, i) * H(:, i)' * pc) / ...
                    betac(i) - ...
                    square_abs(H(:, i)' * pcprecoder / ...
                    betac(i)) * gammac1(i)) >= rhoc(i)


                gamma2=square_abs(H(:,i)'* p)
                gamma1(i)>=LOS(i)*sum(gamma2([1:i-1, i+1:end]))+n0
                gammac1(i)>=LOS(i)*sum(gamma2)+n0



                P1=P1+p(:,i)' * p(:,i)
                t1=t1+Data(i)*inv_pos(R(i))

                
               
                

            end
             for i = 1:K+1
              med_P(i)>=p(:,i)' * p(:,i)+pc' * pc
              E1(i)>=med_P(i)*Data(i)-eta(i).*R(i)
             end

            P2= P1+pc' * pc
            P2<=Pt
            time>=omiga*t1+(1-omiga)*sum(E1)
            cvx_end



            beta = gamma1;
            betac = gammac1;

            fprintf("RSMA | %d | obj = %f | |obj - obj_last| = %f\n", iter, time, abs(time - tPrevious));%将数据写入文本文件

            if(abs(time - tPrevious) <= tolerance)
                break;
            end
            for i=1:K+1
                eta(i)=med_P(i)*Data(i)./(R(i))
            end
            tPrevious = time;
            Pp = p;
            pcprecoder=pc;
        end
        RSMA_Rate{j}=R;


        Name = {'1' '2' '3' '4' '5' '6' '7' '8' '9'};
        addpath(genpath(pwd));
        %     input_file = 'Inception V4.mat';
        Q=[MHPCP{j,5} MHPCP{j,6}];
        for i=1:K+1
            t_com(:,i)=Inceptionv4_cost'./Q(i);
            t_tran(:,i)=Inceptionv4_weights./(R(i)*B);
            E_com(:,i)= Inceptionv4_cost*E_flops;
            E_tran(:,i)=(p(:,i)' * p(:,i)+pc' * pc)*t_tran(:,i);
        end
        cost_table=omiga*t_com*1000+(1-omiga)*E_com;
        weights=omiga*t_tran+(1-omiga)*E_tran;
        Graph = digraph;
        s = [1 1 1 1 2 3 4 5 6 7 8 ];
        t = [2 3 4 6 9 9 5 9 7 8 9 ];
        Graph = addedge(Graph,s,t);
        Graph.Nodes.Name = Name';
        % Print the input graph and cost table for the HEFT algorithm
        %     printHeftInput(Graph,cost_table);

        % Run HEFT scheduling algorithm
        [ScheduleDB]  = heft(Graph,cost_table,weights);

        data_tran_matrix=sparse(s, t, Inceptionv4_weights, 9, 9);
        data_tran_matrix= full(data_tran_matrix);
        curr_Rate(:,A_iter)=R;
        curr_plan=table2array(ScheduleDB.NodeSchedule(:,3));
        curr_plan2(:,A_iter)=curr_plan;
        for i=2:size(curr_plan)
            node_predecessors=predecessors(Graph,i);

            for n = 1:length(node_predecessors)
                if curr_plan(node_predecessors(n)) ~= curr_plan(i) || node_predecessors(n) == 1
                    Data(curr_plan(i)) = Data(curr_plan(i)) + data_tran_matrix(node_predecessors(n), i);
                end
            end
            % Prints the schedule result
            % set 'separate_figures' to true to separate result figures
        end
        %     separate_figures = true;
        %     plotSchedule(ScheduleDB, separate_figures);
        Data =Data ./ B;
        curr_Rate1=curr_Rate;
        curr_plan1=curr_plan;
        curr_K(A_iter)=ScheduleDB.Cycles;

    end
    % Prints the schedule result
    % set 'separate_figures' to true to separate result figures
%     separate_figures = true;
%     plotSchedule(ScheduleDB, separate_figures);

    K_HEFT(j)=ScheduleDB.Cycles;
    plan(:,j)=curr_plan1
    offloading_plan{j}=ScheduleDB.NodeSchedule;

    rmpath(genpath(pwd));
    curr_Rate=[];
    curr_plan2=[];

fprintf("vehicle | %d | delay = %f | ", j, K_HEFT(j) );

end



