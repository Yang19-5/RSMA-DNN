% % load('RSMA_O.mat')
% % edge_delay=K_AVE3;
% load('RSMA_picture1.mat')
% RSAM_delay=[K_AVE1];
% random_delay=[K_AVE2];
% edge_delay=[K_AVE3];
% local_delay=[K_AVE4];
% picnumup=80:5:120;
% % load('RSMA_picture1.mat')
% filename = 'RSMA_picture2.mat';
% save(filename, ...
%     'picnumup',...
%     'RSAM_delay', ...
%     'random_delay', ...
%     'edge_delay', ...
%     'local_delay');
% load('RSMA_LeNet1.mat')
K_AVE1=[920.1	925	940	960	990	];
K_BPA1=[890	905	925	947	985];
% random=K_AVE2;
% load('RSMA_图62.mat')
list=60:6:84;
% line(picnumup,RSAM_delay,'Color',addcolor(185),'Marker','o');
% line(picnumup,random_delay,'Color','k','Marker','+');
% line(picnumup,edge_delay,'Color',addcolor(178),'Marker','*');
% line(picnumup,local_delay,'Color',addcolor(130),'Marker','x');
% legend({'\fontname{Times New Roman}Proposed','\fontname{Times New Roman}random',...
%     '\fontname{Times New Roman}all offloading BS','\fontname{Times New Roman}local,'},'FontSize',11);
% xlabel('\fontname{Times New Roman}\fontsize{11}data size');
% ylabel('\fontname{Times New Roman}\fontsize{11}sum delay');
% grid on;
picnumup=list;
set(gca,'box','on');
line(picnumup,K_AVE1,'Color','g','Marker','o','LineWidth', 1.5,'MarkerSize', 5);
line(picnumup,K_BPA1,'Color','r','Marker','+','LineWidth', 1.2,'MarkerSize', 5,'linestyle','--');
% line(picnumup,K_AVE3,'Color','b','Marker','*','LineWidth', 1.2,'MarkerSize', 5,'linestyle','--');
% line(picnumup,K_AVE4,'Color','k','Marker','x','LineWidth', 1.2,'MarkerSize', 5,'linestyle','--');
% line(picnumup,K_BPA1,'Color','m','Marker','|','LineWidth', 1.2,'MarkerSize', 5,'linestyle','--');
legend('main','BCP',...
    'AOS','LOS','BPA','FontSize',12,'Interpreter','latex');
xlabel('data','Interpreter','latex');
ylabel('cost','Interpreter','latex');
set(get(gca, 'Xlabel'),'Fontname','Times New Roman','FontWeight','bold','Fontsize',13,'Interpreter','latex'); % X轴标签字体，字号设置
set(get(gca, 'Ylabel'),'Fontname','Times New Roman','FontWeight','bold','Fontsize',13,'Interpreter','latex'); % Y轴标签字体，字号设置
grid on;