%% 三种建模交通对比图
clc;clear;close all;
%% mhcpp分布图
%% step 1 泊松点分布
X1 = 0.1;
x1 = 1000*X1;                       % 密度
M = 0;
U = unifrnd(0,1);

while U >= exp(-x1)           %判定条件
   U = U*unifrnd(0,1);
   M=M+1;
end 

if M < 1
   M = 1;
end

L = 300;
a = 0;b = L;      %取[0,100]*[0,100]的布点区域；
A = zeros(1,M);
% B = zeros(1,M);
for i = 1:M 
    U1 = unifrnd(0,1);
    A(i) = (b-a)*U1;
%     plot(A(i),B,'r^'); %(Ai),B(i)分别为横坐标和纵坐标,，'r^'表示线条颜色为红色，
%     hold on;
end
% grid on;
Hppp=[A];

%% step 2  标记点
mark=unifrnd(0,1,1,M); % 对应于Hppp矩阵,0到1之间，1行M列
[marknew,index]=sort(mark);  %Matlab中给一维向量排序是使用sort函数: sort (X)，其中x为待排序的向量。若欲保留排列前的索引，则可用[sX,index] = sort(X)，
%排序后，sX是排序好的向量，index是 向量sX中对X的索引。事实上这里X=sX(index), [X恒等于sX(index)]，

for i=1:length(mark)
    newmatrix(:,i)=Hppp(:,index(i)); %index(i)表示index矩阵中第i个元素
end

%计算两点之间的距离
distance=zeros(length(mark),length(mark));
for i=1:length(mark)
for j=i+1:length(mark)
 distance(i,j)=sqrt(sum((newmatrix(:,i)-newmatrix(:,j)).^2)); %计算列与列间欧式几何距离
end
end
distance=distance+distance'; %b应该是对角矩阵，上边循环只计算一半，这里补另一半

%% step3距离判别

Y1=5; % 硬核距离
j=1; interindex=0;
indexpoint=ones(1,length(mark));%生成1行length(mark)列的全1矩阵
dis=(distance>=Y1);

for i=1:length(mark)
    for j=i+1:length(mark)
        if indexpoint(i)==1
            if dis(i,j)==0
                indexpoint(j)=0;
            end
        end
    end
end
temp=find(indexpoint==1);

% Mhcpp画图
for t=1:length(temp)
    Mhcpp(:,t)=newmatrix(:,temp(t));
end
mhp=sort(Mhcpp);
% figure(1)
% plot(Mhcpp(1,:),Mhcpp(2,:),'r^')
% title(['vehicle distribution under different models with \lambda_v=',num2str(x1),'(vehicles/km)'])
% grid on;

filename = 'mhp.mat';
save(filename, ...
    'mhp');