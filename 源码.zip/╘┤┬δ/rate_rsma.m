clear all;clc;
load('0719_system_v30p30.mat');
%config;
Pt=1;
B=10^6;%带宽2MHZ
P0 = 10 ^ (-94/10); %-94dbm
n0 = 10 ^ (-174/10)/1000*B*(1e6)^2; %-94dbm
%噪声功率-174dBm 
yita=0.5;%公私有初始功率分配系数
a=1e15;
P_c = Pt * (1-yita);%初始公私有功率值
P_p = yita*Pt / K;

rate_min=1e3;

[U, ~, ~] = svd(H);%svd分解
p1precoder = U(:, 1) * sqrt(P_c);%公有预编码方向
Priprecoder = H ./ vecnorm(H) * sqrt(P_p);%私有预编码方向矩阵
pE2precoder = Priprecoder(:, 1);%1代表辅助计算mecBS，2代表辅助计算车辆ub
pb2precoder = Priprecoder(:, 2);

p1precoder=repmat(p1precoder,1,t_stay1);%为每一个t时刻预编码矩阵
pE2precoder=repmat(pE2precoder,1,t_stay1);
pb2precoder=repmat(pb2precoder,1,t_stay1);

for t=1:t_stay1
  
    % ploss_aE(t)=dis_aE_min_t(t)^(-alpha_m);
    % ploss_ab(t)=dis_ab_min_t(t)^(-alpha_m);%路损ploss_0*
    
    gamma_m2(t,:) = n0+[ploss_aE(t)*square_abs(H(:, 1)' * pb2precoder(:,t)), ...
                     ploss_ab(t)*square_abs(H(:, 2)' * pE2precoder(:,t))];
    
    gamma_m1(t,:) = n0+[ploss_aE(t)*(square_abs(H(:, 1)' * pE2precoder(:,t)) + ...
                         square_abs(H(:, 1)' * pb2precoder(:,t))), ...
                     ploss_ab(t)*(square_abs(H(:, 2)' * pE2precoder(:,t)) + ...
                         square_abs(H(:, 2)' * pb2precoder(:,t)))];
end


for t=1:t_stay1
    % [pE2(t), pb2(t), p1(t), c(t), maxsumrate(t),Rate_aE(t),Rate_ab(t)] = ...
    % f5_rsma_sca(H, tolerance,ploss_aE(t),ploss_ab(t),...
    % pb2precoder,pE2precoder,p1precoder,gamma_m1(t,:),gamma_m2(t,:));


    kPrevious = -inf;%无穷小

    maxIter = 1000;
    for iter = 1:maxIter

cvx_begin quiet
    variable k
    variable alphaE2
    variable alphab2
    variable alphaE1
    variable alphab1
    variable gamma_E2
    variable gamma_b2
    variable gamma_E1
    variable gamma_b1
    variable rho_E2
    variable rho_b2
    variable rho_E1
    variable rho_b1
    variable pE2(Nt) complex
    variable pb2(Nt) complex
    variable p1(Nt) complex
    variable c(2)

    maximize(k)
    subject to

        c(1) >= 0 % c(1)E c(2)b 公有子速率   1代表辅助计算mecBS，2代表辅助计算车辆ub
        c(2) >= 0  %C4

        c(1) + c(2) <= alphaE1
        c(1) + c(2) <= alphab1 %公有速率约束 C2

        c(1) + alphaE2 >= rate_min
        c(2) + alphab2 >= rate_min  %C3       

        k <= c(1) + c(2)+ alphaE2 + alphab2

        a*(log(1+rho_E1) / log(2)) >= a*alphaE1
        a*(log(1+rho_b1) / log(2)) >= a*alphab1%各节点公有速率 
        a*B*(log(1+rho_E2) / log(2)) >= a*alphaE2
        a*B*(log(1+rho_b2) / log(2)) >= a*alphab2%各节点私有速率 
        % log(1+rho_E1) / log(2) >= alphaE1
        % log(1+rho_b1) / log(2) >= alphab1%各节点公有速率 
        % log(1+rho_E2) / log(2) >= alphaE2
        % log(1+rho_b2) / log(2) >= alphab2%各节点私有速率 


        a*ploss_aE(t) * (2 * real(pE2precoder(:,t)' * H(:, 1) * H(:, 1)' * pE2) / ...
            gamma_m2(t,1) - ...
            square_abs(H(:, 1)' * pE2precoder(:,t) / ...
            gamma_m2(t,1)) * gamma_E2) >= a*rho_E2
        a*ploss_ab(t) * (2 * real(pb2precoder(:,t)' * H(:, 2) * H(:, 2)' * pb2) / ...
            gamma_m2(t,2) - ...
            square_abs(H(:, 2)' * pb2precoder(:,t) / ...
            gamma_m2(t,2)) * gamma_b2) >= a*rho_b2  %C5

        a*ploss_aE(t) * (2 * real(p1precoder(:,t)' * H(:, 1) * H(:, 1)' * p1) / ...
            gamma_m1(t,1) - ...
            square_abs(H(:, 1)' * p1precoder(:,t) / ...
            gamma_m1(t,1)) * gamma_E1) >= a*rho_E1     %C6
        a*ploss_ab(t) * (2 * real(p1precoder(:,t)' * H(:, 2) * H(:, 2)' * p1) / ...
            gamma_m1(t,2) - ...
            square_abs(H(:, 2)' * p1precoder(:,t) / ...
            gamma_m1(t,2)) * gamma_b1) >= a*rho_b1

        a*gamma_E2 >= a*(ploss_aE(t) * (square_abs(H(:, 1)' * pb2)) + n0)
        a*gamma_b2 >= a*(ploss_ab(t) * (square_abs(H(:, 2)' * pE2)) + n0)  %(31b)

        a*gamma_E1 >= a*(ploss_aE(t) * (square_abs(H(:, 1)' * pE2) + square_abs(H(:, 1)' * pb2)) + n0) 
        a*gamma_b1 >= a*(ploss_ab(t) * (square_abs(H(:, 2)' * pE2) + square_abs(H(:, 2)' * pb2)) + n0)  %(33b)

        a*(pE2' * pE2 + pb2' * pb2 + p1' * p1) <= a*Pt   %功率约束 C1

%         a*(ploss_aE(t)*(2 * real(p1precoder(:,t)' * H(:, 1) * H(:, 1)' * p1) - ...
%             square_abs(H(:, 1)' * p1precoder(:,t)) - square_abs(H(:, 1)' * pb2)...
%             - square_abs(H(:, 1)' * pE2)) -n0) >= a*P0  %SIC检测要求 (30)
%         
%         a*(ploss_ab(t)*(2 * real(p1precoder(:,t)' * H(:, 2) * H(:, 2)' * p1) - ...
%             square_abs(H(:, 2)' * p1precoder(:,t)) - square_abs(H(:, 2)' * pb2)...
%             - square_abs(H(:, 2)' * pE2)) -n0) >= a*P0
cvx_end

    o_gamma_m2 = [gamma_E2, gamma_b2];
    o_gamma_m1 = [gamma_E1, gamma_b1];


    fprintf("RSMA | t = %d s | %d | obj = %f | |obj - obj_last| = %f\n", t, iter, k, abs(k/1e6 - kPrevious/1e6));%将数据写入文本文件
    
    if(abs(k/1e6 - kPrevious/1e6) <= tolerance)
         break;
    end

    kPrevious = k;
    gamma_m2(t,:) = o_gamma_m2;
    gamma_m1(t,:) = o_gamma_m1;
    pE2precoder(:,t) = pE2;
    pb2precoder(:,t) = pb2;
    p1precoder(:,t) = p1;
    
    pE2_0(:,iter) = pE2;
    pb2_0(:,iter) = pb2;
    p1_0(:,iter) = p1;
    k_i(iter,t)=k;
    end
    Rate_aE(t)=c(1) + alphaE2;
    Rate_ab(t)=c(2) + alphab2;
    sumrate(t)=max(k_i(:,t));
    %k_i=0;
    maxsumrate(t) = k/1e6;
end
Rate_ab=Rate_ab/1e6;
Rate_aE=Rate_aE/1e6;
D_end_ab=sum(Rate_ab,"all");
D_end_aE=sum(Rate_aE,"all");
D_end_tot=sum(maxsumrate,"all");

filename = 'rate_0721_rsma_v30p30.mat';
save(filename);
